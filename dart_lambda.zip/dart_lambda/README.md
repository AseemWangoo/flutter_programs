## 📦 Install

Install the [serverless framework](https://www.serverless.com/framework/docs/getting-started/) CLI.

Run the following command in your terminal.

```bash
$ npx serverless install \
  --url https://github.com/katallaxie/serverless-aws-dart \
  --name hello
```

This will download the source of a sample Dart application and unpack it as a new service named
"hello" in a directory called "hello" 👋.


### Invoking function
- curl  https://t264fzf6eh.execute-api.us-east-1.amazonaws.com/dev/hello

- curl -X POST -H "Content-Type: application/json" \
 -d '{"name": "aseem"}' \
 https://t264fzf6eh.execute-api.us-east-1.amazonaws.com/dev/postRequest
