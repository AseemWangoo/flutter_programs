import 'dart:convert';
import 'dart:io';

import 'package:aws_lambda_dart_runtime/aws_lambda_dart_runtime.dart';

import 'post-request/post_request.dart';

void main() async {
  final Handler<AwsApiGatewayEvent> helloApiGateway = (context, event) async {
    // CREATING MAP
    final resp = {
      'message': 'Hello to ${context.requestId}',
      'host': '${event.headers.host}',
      'userAgent': '${event.headers.userAgent}',
    };

    final response = AwsApiGatewayResponse(
      body: json.encode(resp),
      isBase64Encoded: false,
      statusCode: HttpStatus.ok,
      headers: {
        "Content-Type": "application/json",
      },
    );

    return response;
  };

  /// The Runtime is a singleton. You can define the handlers as you wish.
  Runtime()
    ..registerHandler<AwsApiGatewayEvent>("main.hello", helloApiGateway)
    ..registerHandler<AwsApiGatewayEvent>(
      "main.postRequest",
      PostRequest().postApiGateway,
    )
    ..invoke();
}
