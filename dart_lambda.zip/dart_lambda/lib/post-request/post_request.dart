import 'dart:io';

import 'package:aws_lambda_dart_runtime/aws_lambda_dart_runtime.dart';

import 'model/post_request_model.dart';
import 'model/response_model.dart';

class PostRequest {
  PostRequest();

  final Handler<AwsApiGatewayEvent> postApiGateway = (context, event) async {
    final requestBody = event.body;
    final requestModel = postRequestModelFromJson(requestBody);

    final responseBody = ResponseModel(
      message: 'Hello ${requestModel.name} from AWS Lambda!!',
    );

    final response = AwsApiGatewayResponse(
      body: responseModelToJson(responseBody),
      isBase64Encoded: false,
      statusCode: HttpStatus.ok,
      headers: {
        "Content-Type": "application/json",
      },
    );

    return response;
  };
}
