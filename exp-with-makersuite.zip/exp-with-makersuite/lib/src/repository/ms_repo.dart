import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

abstract class MSRepository {
  Future<String> textPrompt(String prompt);
  Future<String> chatPrompt(String prompt);
}

class MSRepositoryImpl implements MSRepository {
  @override
  Future<String> textPrompt(String prompt) async {
    try {
      final url = Uri.parse('http://127.0.0.1:1234/textPrompt');

      final headers = {'Content-Type': 'application/json'};

      final body = jsonEncode({
        'prompt': prompt,
      });

      final response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        final decodedResponse = json.decode(response.body);

        return decodedResponse['bot'];
      } else {
        throw Exception('Something went wrong in textPrompt');
      }
    } catch (err) {
      debugPrint(err.toString());
    }

    return 'Something went wrong in textPrompt';
  }

  @override
  Future<String> chatPrompt(String prompt) async {
    try {
      final url = Uri.parse('http://127.0.0.1:1234/chatPrompt');

      final headers = {'Content-Type': 'application/json'};

      final body = jsonEncode({
        'prompt': prompt,
      });

      final response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        final decodedResponse = json.decode(response.body);

        return decodedResponse['bot'];
      } else {
        throw Exception('Something went wrong in chatPrompt');
      }
    } catch (err) {
      debugPrint(err.toString());
    }

    return 'Something went wrong in chatPrompt';
  }
}
