import 'package:exp_with_makersuite/src/repository/ms_repo.dart';
import 'package:flutter/material.dart';

import '../../view_models/loading_view_model.dart';

enum MSMode { textMode, chatMode }

class ChatViewModel extends LoadingViewModel {
  ChatViewModel({
    required MSRepository msRepository,
  }) : _msRepository = msRepository;

  final MSRepository _msRepository;

  String resp = '';
  MSMode mode = MSMode.textMode;
  String displayMode = 'text mode';

  void setMode(String value) {
    if (value == 'textMode') {
      mode = MSMode.textMode;
      displayMode = 'text mode';
    } else {
      mode = MSMode.chatMode;
      displayMode = 'chat mode';
    }

    notifyListeners();
  }

  Future<String> textPrompt(String prompt) async {
    isLoading = true;
    resp = await _msRepository.textPrompt(prompt);
    isLoading = false;
    return resp;
  }

  Future<String> chatPrompt(String prompt) async {
    isLoading = true;
    resp = await _msRepository.chatPrompt(prompt);
    isLoading = false;
    return resp;
  }

  List<PopupMenuEntry<String>> items = const [
    PopupMenuItem<String>(
      value: 'textMode',
      child: Text('Text Mode'),
    ),
    PopupMenuItem<String>(
      value: 'chatMode',
      child: Text('Chat Mode'),
    ),
  ];
}
