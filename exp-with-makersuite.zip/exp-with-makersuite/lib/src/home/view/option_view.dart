import 'package:exp_with_makersuite/src/home/view/chat_view.dart';
import 'package:exp_with_makersuite/src/home/view/home_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../view_model/home_view_model.dart';

class OptionView extends StatefulWidget {
  const OptionView({super.key});

  @override
  State<OptionView> createState() => _OptionViewState();
}

class _OptionViewState extends State<OptionView> {
  late HomeViewModel viewModel;

  String _textQuery = '';
  final TextEditingController _textController = TextEditingController();
  late FocusNode textFocusNode;

  List<String> chatHistory = [];
  List<String> respHistory = [];

  @override
  void initState() {
    super.initState();
    viewModel = context.read();

    // For text controllers
    textFocusNode = FocusNode();
    textFocusNode.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('Flutter and MakerSuite'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const HomeView(),
                      ),
                    );
                  },
                  style: TextButton.styleFrom(
                    backgroundColor: Colors.yellow,
                  ),
                  child: const Text(
                    'Boring Mode',
                    style: TextStyle(fontSize: 20),
                  ),
                ),
                const SizedBox(height: 40),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ChatView(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                  ),
                  child: const Text(
                    'Cool Mode',
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void handleClear() {
    setState(() {
      _textController.clear();
    });
    textFocusNode.requestFocus();
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  Future<String> callApi(String prompt) async {
    if (viewModel.mode == MSMode.textMode) {
      return viewModel.textPrompt(prompt);
    }

    return viewModel.chatPrompt(prompt);
  }
}
