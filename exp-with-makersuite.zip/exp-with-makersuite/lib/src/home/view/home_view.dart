import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../view_model/home_view_model.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  late HomeViewModel viewModel;

  String _textQuery = '';
  final TextEditingController _textController = TextEditingController();
  late FocusNode textFocusNode;

  List<String> chatHistory = [];
  List<String> respHistory = [];

  @override
  void initState() {
    super.initState();
    viewModel = context.read();

    // For text controllers
    textFocusNode = FocusNode();
    textFocusNode.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('Flutter and MakerSuite'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (String result) {
              viewModel.setMode(result);
              respHistory.clear();
              chatHistory.clear();
            },
            itemBuilder: (context) {
              return viewModel.items;
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Consumer<HomeViewModel>(
          builder: (context, model, child) {
            if (model.isLoading) {
              return child!;
            }

            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: <Widget>[
                  const SizedBox(height: 40),
                  Text(
                    'You are in ${viewModel.displayMode}',
                    style: const TextStyle(fontSize: 20),
                  ),
                  const SizedBox(height: 40),
                  TextField(
                    controller: _textController,
                    onChanged: (value) {
                      setState(() => _textQuery = value);
                    },
                    onSubmitted: (value) {
                      chatHistory.add(value);
                      callApi(value).then((value) => respHistory.add(value));

                      handleClear();
                    },
                    maxLines: 1,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Type here...',
                      labelText: 'Your Query',
                    ),
                  ),
                  const SizedBox(height: 40),
                  if (chatHistory.isNotEmpty)
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          'Query:',
                          textAlign: TextAlign.left,
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  for (var i = 0; i < chatHistory.length; i++) ...[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          child:
                              Text(chatHistory[i], textAlign: TextAlign.left),
                        ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 40),
                  if (respHistory.isNotEmpty)
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          'Response:',
                          textAlign: TextAlign.left,
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  for (var i = 0; i < respHistory.length; i++) ...[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          child:
                              Text(respHistory[i], textAlign: TextAlign.left),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            );
          },
          child: const Center(
            child: CircularProgressIndicator(
              color: Colors.green,
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          chatHistory.add(_textQuery);
          callApi(_textQuery).then((value) => respHistory.add(value));

          handleClear();
        },
        tooltip: 'Send',
        child: const Icon(Icons.send),
      ),
    );
  }

  void handleClear() {
    setState(() {
      _textController.clear();
    });
    textFocusNode.requestFocus();
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  Future<String> callApi(String prompt) async {
    if (viewModel.mode == MSMode.textMode) {
      return viewModel.textPrompt(prompt);
    }

    return viewModel.chatPrompt(prompt);
  }
}
