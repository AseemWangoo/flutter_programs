import 'package:exp_with_makersuite/src/home/view_model/chat_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

class ChatView extends StatefulWidget {
  const ChatView({super.key});

  @override
  State<ChatView> createState() => _ChatViewState();
}

class _ChatViewState extends State<ChatView> {
  final List<types.Message> _messages = [];
  late ChatViewModel viewModel;

  final _user = const types.User(
    id: '82091008-a484-4a89-ae75-a22bf8d6f3ac',
    firstName: 'Me',
  );

  final _bard = const types.User(
    id: 'a9059aa5-4f3a-4e95-8574-a2866246872f',
    firstName: 'Google Bard',
  );

  @override
  void initState() {
    super.initState();
    viewModel = context.read();

    _addMessage(types.TextMessage(
      author: _bard,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      id: const Uuid().v4(),
      text: 'You are in ${viewModel.displayMode}',
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('Flutter and MakerSuite'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (String result) {
              setState(() {
                viewModel.setMode(result);
              });

              _addMessage(types.TextMessage(
                author: _bard,
                createdAt: DateTime.now().millisecondsSinceEpoch,
                id: const Uuid().v4(),
                text: 'You are in ${viewModel.displayMode}',
              ));
            },
            itemBuilder: (context) => viewModel.items,
          ),
        ],
      ),
      body: Chat(
        messages: _messages,
        onSendPressed: _handleSendPressed,
        user: _user,
        showUserAvatars: true,
        showUserNames: true,
      ),
    );
  }

  void _addMessage(types.Message message) {
    setState(() {
      _messages.insert(0, message);
    });
  }

  void _handleSendPressed(types.PartialText message) {
    final textMessage = types.TextMessage(
      author: _user,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      id: const Uuid().v4(),
      text: message.text,
    );

    _addMessage(textMessage);

    viewModel.chatPrompt(message.text).then((value) {
      setState(() {
        _messages.insert(
          0,
          types.TextMessage(
            author: _bard,
            createdAt: DateTime.now().millisecondsSinceEpoch,
            id: const Uuid().v4(),
            text: value,
          ),
        );
      });
    });
  }
}
