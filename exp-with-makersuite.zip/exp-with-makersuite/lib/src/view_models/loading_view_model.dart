import 'package:flutter/foundation.dart';

class LoadingViewModel extends ChangeNotifier {
  bool get isLoading => _isLoading;

  set isLoading(bool isLoading) {
    _isLoading = isLoading;
    notifyListeners();
  }

  bool _isLoading = false;
}
