import 'package:exp_with_makersuite/src/repository/ms_repo.dart';
import 'package:get_it/get_it.dart';

final locator = GetIt.instance;

void setupLocator() {
  _setupSingletons();
  _setupFactories();
}

void _setupFactories() {
  locator.registerFactory<MSRepository>(
    () => MSRepositoryImpl(),
  );
}

// Place where we put all the singletons
void _setupSingletons() {}
