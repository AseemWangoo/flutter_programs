import 'package:exp_with_makersuite/src/home/view/chat_view.dart';
import 'package:exp_with_makersuite/src/home/view/home_view.dart';
import 'package:exp_with_makersuite/src/home/view/option_view.dart';
import 'package:exp_with_makersuite/src/home/view_model/chat_view_model.dart';
import 'package:exp_with_makersuite/src/home/view_model/home_view_model.dart';
import 'package:exp_with_makersuite/src/repository/ms_repo.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'locator.dart';

void main() {
  // Init the service locator
  setupLocator();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => HomeViewModel(
            msRepository: locator<MSRepository>(),
          ),
        ),
        ChangeNotifierProvider(
          create: (context) => ChatViewModel(
            msRepository: locator<MSRepository>(),
          ),
        ),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter and MakerSuite',
      theme: ThemeData(
        useMaterial3: true,
      ),
      // home: const HomeView(),
      // home: const ChatView(),
      home: const OptionView(),
      debugShowCheckedModeBanner: false,
    );
  }
}
