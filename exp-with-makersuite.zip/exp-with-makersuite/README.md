# Makersuite

A new Flutter project.

## Playing

- Prompts

```
hello bard, how are you
whats the weather in australia, keep it short
whats the weather in singapore, keep it short
whats the weather in canada, keep it short
```

For convo

```
hello bard, how are you
I am Aseem. Nice to meet you.
Where do you stay
I got it. Can you help in checking the temperature today?
How about Singapore
and will it rain today
thanks bard, can you remind me what country was I asking for?
```
