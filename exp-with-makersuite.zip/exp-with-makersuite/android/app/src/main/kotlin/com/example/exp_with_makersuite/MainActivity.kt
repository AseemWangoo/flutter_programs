package com.example.exp_with_makersuite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
