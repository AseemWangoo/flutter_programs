package com.example.ffi_talk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
