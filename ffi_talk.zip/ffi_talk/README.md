# ffi_talk

- Talk on FFI

### For Ffigen
- Specify `ffigen` in pubspec.yaml
- Add the configuration section in pubspec.yaml
- `flutter pub run ffigen`

### For Generating dynamic library
- Navigate to arithmetic folders
- Create a CMakeLists.txt
- Cmake `cmake .` which creates a makefile 
- Run `make`

- This also creates an executable called `arithmetic_test`

### For using in Flutter Desktop
- https://flutter.dev/docs/development/platform-integration/c-interop#compiled-dynamic-library-macos
- Open `Runner.xcworkspace` in XCode
- Follow the steps in the doc
- Note, your dylib is from a folder inside your project. In my case, I used `lib/library/libarithmetic.dylib`

- In the last step

When you come in Runner-> General, inside `Frameworks, Libraries and Embedded Content`, if the library is present
remove it and add again

- Place the dylib inside the macos folder also