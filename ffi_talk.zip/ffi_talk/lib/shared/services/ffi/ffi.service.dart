import 'dart:ffi';

import 'package:ffi_talk/generated/arithmetic/generated_bindings.dart';

class FfiService {
  int arithmeticAdd(int a, int b) {
    final dyLib = DynamicLibrary.open(
      'libarithmetic.dylib',
    );

    final arithmeticLib = ArithmeticLibrary(dyLib);
    return arithmeticLib.sum(a, b);
  }

  int arithmeticSub(int a, int b) {
    final dyLib = DynamicLibrary.open(
      'libarithmetic.dylib',
    );

    final arithmeticLib = ArithmeticLibrary(dyLib);
    return arithmeticLib.subtract(a, b);
  }

  int arithmeticMul(int a, int b) {
    final dyLib = DynamicLibrary.open(
      'libarithmetic.dylib',
    );

    final arithmeticLib = ArithmeticLibrary(dyLib);
    return arithmeticLib.multiply(a, b);
  }

  double arithmeticDiv(int a, int b) {
    final dyLib = DynamicLibrary.open(
      'libarithmetic.dylib',
    );

    final arithmeticLib = ArithmeticLibrary(dyLib);
    return arithmeticLib.divide(a, b);
  }
}
