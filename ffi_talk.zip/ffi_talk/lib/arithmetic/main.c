#include <stdio.h>
#include "ops.h"

int main()
{
    int add, sub, mul;
    float div;

    add = sum(4,2);
    sub = subtract(4,2);
    mul = multiply(4,2);
    div = divide(4,2);

    printf("Sum is: %d\n", add);
    printf("Diff is: %d\n", sub);
    printf("Mul is: %d\n", mul);
    printf("Div is: %f\n", div);

    return 0;
}

