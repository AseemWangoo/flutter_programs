import 'package:flutter/material.dart';

import 'locator.dart';
import 'shared/services/ffi/ffi.service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // INIT SERVICE LOCATOR
  setupLocator();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FFI Talk',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final ffiService = locator<FfiService>();
  final c1 = TextEditingController(text: '1');
  final c2 = TextEditingController(text: '1');

  int inputA = 1;
  int inputB = 1;

  @override
  void initState() {
    c1.addListener(_inputA);
    c2.addListener(_inputB);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final add = ffiService.arithmeticAdd(inputA, inputB);
    final sub = ffiService.arithmeticSub(inputA, inputB);
    final mul = ffiService.arithmeticMul(inputA, inputB);
    final div = ffiService.arithmeticDiv(inputA, inputB);

    return Scaffold(
      appBar: AppBar(
        title: Text('Call C Library using FFI (MacOS)'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Arithmetic Ops from C',
                style: Theme.of(context)
                    .primaryTextTheme
                    .headline6
                    ?.copyWith(color: Colors.black)),
            SizedBox(height: 20),
            Text('Enter 2 inputs'),
            SizedBox(
              width: 200,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: TextField(
                      controller: c1,
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  const SizedBox(width: 20),
                  Flexible(
                    child: TextField(
                      controller: c2,
                      keyboardType: TextInputType.number,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Text('Addition : ${add.toString()}'),
            SizedBox(height: 20),
            Text('Subtraction : ${sub.toString()}'),
            SizedBox(height: 20),
            Text('Multiply : ${mul.toString()}'),
            SizedBox(height: 20),
            Text('Divide : ${div.toStringAsFixed(2)}'),
          ],
        ),
      ),
    );
  }

  void _inputA() {
    if (c1.text.isNotEmpty) {
      setState(() {
        inputA = int.parse(c1.text);
      });
    }
  }

  void _inputB() {
    if (c2.text.isNotEmpty) {
      setState(() {
        inputB = int.parse(c2.text);
      });
    }
  }

  @override
  void dispose() {
    c1.dispose();
    c2.dispose();
    super.dispose();
  }
}
