### Links
- https://youtu.be/0pf2fQxZ_AI

- https://cmake.org/cmake/help/latest/guide/tutorial/A%20Basic%20Starting%20Point.html