import 'package:flutter/material.dart';

import 'locator.dart';
import 'shared/services/ffi/ffi.service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // INIT SERVICE LOCATOR
  setupLocator();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const Home(),
    );
  }
}

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final ffiService = locator<FfiService>();
    final val = ffiService.fetchRandomNumber();

    final revVal = ffiService.stringReverse('Hello world');
    final name = ffiService.structsSample('Aseem', 'Wangoo');

    return Scaffold(
      appBar: AppBar(
        title: Text('FFI Linux'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Getting Value from C'),
            Text('Random Number : ${val.toString()}'),
            SizedBox(height: 50),
            Text('Passing Param to C'),
            Text('String reversed : $revVal'),
            SizedBox(height: 50),
            Text('Passing Struct to C'),
            Text('My name : $name'),
          ],
        ),
      ),
    );
  }
}
