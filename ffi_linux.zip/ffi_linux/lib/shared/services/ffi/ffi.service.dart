import 'dart:ffi';

import 'package:ffi/ffi.dart';

// ignore: camel_case_types
typedef fetch_number_func = Int32 Function();
typedef FetchNumber = int Function();

// For structs
typedef CreateNameNative = Name Function(
    Pointer<Utf8> firstName, Pointer<Utf8> lastName);
typedef CreateName = Name Function(
    Pointer<Utf8> firstName, Pointer<Utf8> lastName);

class FfiService {
  int fetchRandomNumber() {
    try {
      final dyLib = DynamicLibrary.open(
        'lib/library/linux/librandomnumber.so',
      );

      final fetchNumberPointer =
          dyLib.lookup<NativeFunction<fetch_number_func>>(
        'fetch_number',
      );

      final number = fetchNumberPointer.asFunction<FetchNumber>();
      return number();
    } catch (exc) {
      // ignore: avoid_print
      print('Something went wrong in fetchRandomNumber ${exc.toString()}');
    }

    return 0;
  }

  String stringReverse(String input) {
    final dylib = DynamicLibrary.open(
      'lib/library/linux/libstringops.so',
    );

    final inputToUtf8 = input.toNativeUtf8();

    final reverse = dylib.lookupFunction<Void Function(Pointer<Utf8>),
        void Function(Pointer<Utf8>)>('reverse');

    reverse(inputToUtf8);
    final resp = inputToUtf8.toDartString();
    malloc.free(inputToUtf8);

    return resp;
  }

  String structsSample(String first, String second) {
    final dylib = DynamicLibrary.open(
      'lib/library/linux/libstringops.so',
    );

    final createName =
        dylib.lookupFunction<CreateNameNative, CreateName>('create_name');

    final fNameUtf8 = first.toNativeUtf8();
    final lNameUtf8 = second.toNativeUtf8();
    final name = createName(fNameUtf8, lNameUtf8);

    final fname = name.firstName.toDartString();
    final lname = name.lastName.toDartString();

    malloc.free(fNameUtf8);
    malloc.free(lNameUtf8);

    return '$fname $lname';
  }
}

class Name extends Struct {
  external Pointer<Utf8> firstName;
  external Pointer<Utf8> lastName;
}
