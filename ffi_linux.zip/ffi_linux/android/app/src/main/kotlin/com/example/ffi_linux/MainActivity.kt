package com.example.ffi_linux

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
