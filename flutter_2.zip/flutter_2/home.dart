import 'package:flutter/material.dart';

import '../flutter_2.dart';

class Home extends StatelessWidget {
  const Home({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    //

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Flutter 2 Widgets',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 8),
            Text('Link Widget'),
            const SizedBox(height: 8),
            LinkerDemo(),
            const SizedBox(height: 12),
            CupertinoSearchDemo(),
            const SizedBox(height: 12),
            CupertinoFormDemo(),
            const SizedBox(height: 12),
            Text('Scaffold Messenger'),
            ScaffoldMessengerDemo(),
            const SizedBox(height: 22),
            Text('RawAutoComplete'),
            RawAutocompleteDemo(),
          ],
        ),
      ),
    );
  }
}
