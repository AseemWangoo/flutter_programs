class CurrentUser {
  static String uid = '';

  static const String key = 'YOUR KEY';
}
